<h1 align="center">SWMAL</h1>
<h3 align="center">Assignment O1</h3>
<h3 align="center">Group 24</h3>
<h5 align="center">September 15 2023</h5>


|Name|Student Number |
|:---|:---|
|Sean Harboe Bateman|200203025|
|Martin Stokholm Lauridsen|201908195|
|Christain Duwe Konnerup|202010016|