def helloworld(msg):
    print(f"Hello world! And hello {msg}")


def goodbyeworld(msg):
    print(f"Goodbye cruel world! And goodbye {msg}")
